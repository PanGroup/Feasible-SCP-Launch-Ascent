%-------------------------------------------------------------------------%
% ���ݴ���
%-------------------------------------------------------------------------%
clc
clear
close all

% ���ù���·��
currentPath = pwd;
addpath(genpath(currentPath));

% ȫ�ֲ���
global globalParam modelParam projParam
globalParam      =  globalParamSetting();
projParam        =  projParamSetting();
modelParam       =  modelParamSetting();
Lnond            =  globalParam.Lnond;
Vnond            =  globalParam.Vnond;
Tnond            =  globalParam.Tnond;
d2r              =  globalParam.d2r;
r2d              =  globalParam.r2d;
tShutdown2       =  modelParam.tShutdown2;
OmegaeMatrix     =  projParam.OmegaeMatrix;
Rad0_A           =  projParam.Rad0_A;
Iz_A             =  projParam.Iz_A;
Rf_A             =  projParam.Rf_A;
Vf_A             =  projParam.Vf_A;
Incf             =  projParam.inc;
LocalThetaf_A    =  projParam.localThetaf_A;

%��������
DataGPOPS        =  load('.\Data Lib\resultTraj-GPOPS.mat');
DataFSCP         =  load('.\Data Lib\resultTraj-FeasibleSCP.mat');
DataPSCP         =  load('.\Data Lib\resultTraj-PicardSCP.mat');

timeGPOPS        =  DataGPOPS.tNominal;
stateGPOPS       =  DataGPOPS.xNominal;
controlGPOPS     =  DataGPOPS.uNominal;

timeFSCP         =  DataFSCP.tNominal;
stateFSCP        =  DataFSCP.xNominal;
controlFSCP      =  DataFSCP.uNominal;

timePSCP         =  DataPSCP.tNominal;
statePSCP        =  DataPSCP.xNominal;
controlPSCP      =  DataPSCP.uNominal;

% ��ֵ����
OptionSet        =  odeset('RelTol',1E-12,'AbsTol',1E-12);
[tGPOPS,xGPOPS]  =  ode45(@sysModelLaunchACoord3D,[timeGPOPS(1),timeGPOPS(end)],stateGPOPS(1,:)',OptionSet,timeGPOPS,controlGPOPS);
[tFSCP,xFSCP]    =  ode45(@sysModelLaunchACoord3D,[timeFSCP(1),timeFSCP(end)],stateFSCP(1,:)',OptionSet,timeFSCP,controlFSCP);
[tPSCP,xPSCP]    =  ode45(@sysModelLaunchACoord3D,[timePSCP(1),timePSCP(end)],statePSCP(1,:)',OptionSet,timePSCP,controlPSCP);

% �������
RfGPOPS          =  norm(xGPOPS(end,1:3)+Rad0_A');
VfGPOPS          =  norm(xGPOPS(end,4:6));
ThetafGPOPS      =  asin(dot(xGPOPS(end,1:3)+Rad0_A',xGPOPS(end,4:6))./norm(xGPOPS(end,1:3)+Rad0_A')./norm(xGPOPS(end,4:6)));
IncfGPOPS        =  acos(dot(Iz_A',cross(xGPOPS(end,1:3)+Rad0_A',xGPOPS(end,4:6)))/norm(cross(xGPOPS(end,1:3)+Rad0_A',xGPOPS(end,4:6))));

RfFSCP           =  norm(xFSCP(end,1:3)+Rad0_A');
VfFSCP           =  norm(xFSCP(end,4:6));
ThetafFSCP       =  asin(dot(xFSCP(end,1:3)+Rad0_A',xFSCP(end,4:6))./norm(xFSCP(end,1:3)+Rad0_A')./norm(xFSCP(end,4:6)));
IncfFSCP         =  acos(dot(Iz_A',cross(xFSCP(end,1:3)+Rad0_A',xFSCP(end,4:6)))/norm(cross(xFSCP(end,1:3)+Rad0_A',xFSCP(end,4:6))));

RfPSCP           =  norm(xPSCP(end,1:3)+Rad0_A');
VfPSCP           =  norm(xPSCP(end,4:6));
ThetafPSCP       =  asin(dot(xPSCP(end,1:3)+Rad0_A',xPSCP(end,4:6))./norm(xPSCP(end,1:3)+Rad0_A')./norm(xPSCP(end,4:6)));
IncfPSCP         =  acos(dot(Iz_A',cross(xPSCP(end,1:3)+Rad0_A',xPSCP(end,4:6)))/norm(cross(xPSCP(end,1:3)+Rad0_A',xPSCP(end,4:6))));

DeltaAlt         =  ([RfGPOPS,RfFSCP,RfPSCP]-Rf_A)*Lnond;
DeltaVel         =  ([VfGPOPS,VfFSCP,VfPSCP]-Vf_A)*Vnond;
DeltaTheta       =  ([ThetafGPOPS,ThetafFSCP,ThetafPSCP]-LocalThetaf_A)*r2d;
DeltaInc         =  ([IncfGPOPS,IncfFSCP,IncfPSCP]-Incf)*r2d;

disp('����ƫ��(GPOPS-FSCP-PSCP):');
disp(['�߶�ƫ�', num2str(DeltaAlt),'m']);
disp(['�ٶ�ƫ�', num2str(DeltaVel),'m/s']);
disp(['�ٶ����ƫ�',num2str(DeltaTheta),'deg']);
disp(['������ƫ�',num2str(DeltaInc),'deg']);

% GPOPS
RadGPOPS         =  bsxfun(@plus,stateGPOPS(:,1:3),Rad0_A');
VelGPOPS         =  stateGPOPS(:,4:6);
RGPOPS           =  sqrt(sum(RadGPOPS.*RadGPOPS,2));
VGPOPS           =  sqrt(sum(VelGPOPS.*VelGPOPS,2));
HGPOPS           =  RGPOPS - 1;
Rho              =  calcuDensity(HGPOPS*Lnond);
Velr             =  VelGPOPS - RadGPOPS*OmegaeMatrix';
Vr               =  sqrt(sum(Velr.*Velr,2));
Ib               =  controlGPOPS./sqrt(sum(controlGPOPS.*controlGPOPS,2));
Ivr              =  Velr./Vr;
AlphaSign        =  cross(Ivr,Ib,2);
AlphaGPOPS       =  sign(AlphaSign(:,3)).*acos(dot(Ib,Ivr,2));
QaGPOPS          =  1/2.*Rho.*Vr.*Vr.*Vnond.*Vnond.*AlphaGPOPS;

LocalThetaGPOPS  =  asin(dot(RadGPOPS,VelGPOPS,2)./RGPOPS./VGPOPS);
IncGPOPS         =  acos(dot(repmat(Iz_A',size(timeGPOPS,1),1),cross(RadGPOPS,VelGPOPS,2),2)...
                 ./sqrt(sum(cross(RadGPOPS,VelGPOPS,2).^2,2)));

% FSCP
RadFSCP          =  bsxfun(@plus,stateFSCP(:,1:3),Rad0_A');
VelFSCP          =  stateFSCP(:,4:6);
RFSCP            =  sqrt(sum(RadFSCP.*RadFSCP,2));
VFSCP            =  sqrt(sum(VelFSCP.*VelFSCP,2));
HFSCP            =  RFSCP - 1;
Rho              =  calcuDensity(HFSCP*Lnond);
Velr             =  VelFSCP - RadFSCP*OmegaeMatrix';
Vr               =  sqrt(sum(Velr.*Velr,2));
Ib               =  controlFSCP./sqrt(sum(controlFSCP.*controlFSCP,2));
Ivr              =  Velr./Vr;
AlphaSign        =  cross(Ivr,Ib,2);
AlphaFSCP        =  sign(AlphaSign(:,3)).*acos(dot(Ib,Ivr,2));
QaFSCP           =  1/2.*Rho.*Vr.*Vr.*Vnond.*Vnond.*AlphaFSCP;

LocalThetaFSCP   =  asin(dot(RadFSCP,VelFSCP,2)./RFSCP./VFSCP);
IncFSCP          =  acos(dot(repmat(Iz_A',size(timeFSCP,1),1),cross(RadFSCP,VelFSCP,2),2)...
                 ./sqrt(sum(cross(RadFSCP,VelFSCP,2).^2,2)));             
             
% PSCP
RadPSCP          =  bsxfun(@plus,statePSCP(:,1:3),Rad0_A');
VelPSCP          =  statePSCP(:,4:6);
RPSCP            =  sqrt(sum(RadPSCP.*RadPSCP,2));
VPSCP            =  sqrt(sum(VelPSCP.*VelPSCP,2));
HPSCP            =  RPSCP - 1;
Rho              =  calcuDensity(HPSCP*Lnond);
Velr             =  VelPSCP - RadPSCP*OmegaeMatrix';
Vr               =  sqrt(sum(Velr.*Velr,2));
Ib               =  controlPSCP./sqrt(sum(controlPSCP.*controlPSCP,2));
Ivr              =  Velr./Vr;
AlphaSign        =  cross(Ivr,Ib,2);
AlphaPSCP        =  sign(AlphaSign(:,3)).*acos(dot(Ib,Ivr,2));
QaPSCP           =  1/2.*Rho.*Vr.*Vr.*Vnond.*Vnond.*AlphaPSCP;

LocalThetaPSCP   =  asin(dot(RadPSCP,VelPSCP,2)./RPSCP./VPSCP);
IncPSCP          =  acos(dot(repmat(Iz_A',size(timePSCP,1),1),cross(RadPSCP,VelPSCP,2),2)...
                 ./sqrt(sum(cross(RadPSCP,VelPSCP,2).^2,2)));

% ��ͼ
figure(1)
hold on
grid on
box on
Delta = 10; Delta2 = 5;
set(figure(1),'Position',[500,200,560,360]);
plot(timeFSCP(1:Delta:end)*Tnond,HFSCP(1:Delta:end)*Lnond/1E3,'b-o','MarkerSize',4.5,'LineWidth',1.6);
plot(timePSCP(1:Delta:end)*Tnond,HPSCP(1:Delta:end)*Lnond/1E3,'r--d','MarkerSize',3,'LineWidth',1.6);
plot(timeGPOPS(1:Delta2:end)*Tnond,HGPOPS(1:Delta2:end)*Lnond/1E3,'k-.x','MarkerSize',6,'LineWidth',1.6);
legend('Feasible-SCP','Picard-SCP','GPOPS');
xlabel('Time (s)');
ylabel('Altitude (km)');

figure(2)
hold on
grid on
box on
set(figure(2),'Position',[500,200,560,360]);
plot(timeFSCP(1:Delta:end)*Tnond,VFSCP(1:Delta:end)*Vnond,'b-o','MarkerSize',4.5,'LineWidth',1.6);
plot(timePSCP(1:Delta:end)*Tnond,VPSCP(1:Delta:end)*Vnond,'r--d','MarkerSize',3,'LineWidth',1.6);
plot(timeGPOPS(1:Delta2:end)*Tnond,VGPOPS(1:Delta2:end)*Vnond,'k-.x','MarkerSize',6,'LineWidth',1.6);
xlabel('Time (s)');
ylabel('Velocity (m/s)');

figure(3)
set(figure(3),'Position',[500,200,560,360]);
subplot(3,1,1)
hold on
grid on
box on
plot(timeFSCP(1:Delta:end)*Tnond,controlFSCP(1:Delta:end,1),'b-o','MarkerSize',4.5,'LineWidth',1.6);
plot(timePSCP(1:Delta:end)*Tnond,controlPSCP(1:Delta:end,1),'r--d','MarkerSize',3,'LineWidth',1.6);
plot(timeGPOPS(1:Delta2:end)*Tnond,controlGPOPS(1:Delta2:end,1),'k-.x','MarkerSize',6,'LineWidth',1.6);
legend('Feasible-SCP','Picard-SCP','GPOPS');
xlabel('Time (s)');
ylabel('Thrust direction-X');
subplot(3,1,2)
hold on
grid on
box on
plot(timeFSCP(1:Delta:end)*Tnond,controlFSCP(1:Delta:end,2),'b-o','MarkerSize',4.5,'LineWidth',1.6);
plot(timePSCP(1:Delta:end)*Tnond,controlPSCP(1:Delta:end,2),'r--d','MarkerSize',3,'LineWidth',1.6);
plot(timeGPOPS(1:Delta2:end)*Tnond,controlGPOPS(1:Delta2:end,2),'k-.x','MarkerSize',6,'LineWidth',1.6);
xlabel('Time (s)');
ylabel('Thrust direction-Y');
subplot(3,1,3)
hold on
grid on
box on
plot(timeFSCP(1:Delta:end)*Tnond,controlFSCP(1:Delta:end,3),'b-o','MarkerSize',4.5,'LineWidth',1.6);
plot(timePSCP(1:Delta:end)*Tnond,controlPSCP(1:Delta:end,3),'r--d','MarkerSize',3,'LineWidth',1.6);
plot(timeGPOPS(1:Delta2:end)*Tnond,controlGPOPS(1:Delta2:end,3),'k-.x','MarkerSize',6,'LineWidth',1.6);
xlabel('Time (s)');
ylabel('Thrust direction-Z');

figure(4)
hold on
grid on
box on
set(figure(4),'Position',[500,200,560,360]);
plot(timeFSCP(1:Delta:end)*Tnond,LocalThetaFSCP(1:Delta:end)*r2d,'b-o','MarkerSize',4.5,'LineWidth',1.6);
plot(timePSCP(1:Delta:end)*Tnond,LocalThetaPSCP(1:Delta:end)*r2d,'r--d','MarkerSize',3,'LineWidth',1.6);
plot(timeGPOPS(1:Delta2:end)*Tnond,LocalThetaGPOPS(1:Delta2:end)*r2d,'k-.x','MarkerSize',6,'LineWidth',1.6);
xlabel('Time (s)');
ylabel('Flight-path angle (deg)');

figure(5)
hold on
grid on
box on
set(figure(5),'Position',[500,200,560,360]);
plot(timeFSCP(1:Delta:end)*Tnond,IncFSCP(1:Delta:end)*r2d,'b-o','MarkerSize',4.5,'LineWidth',1.6);
plot(timePSCP(1:Delta:end)*Tnond,IncPSCP(1:Delta:end)*r2d,'r--d','MarkerSize',3,'LineWidth',1.6);
plot(timeGPOPS(1:Delta2:end)*Tnond,IncGPOPS(1:Delta2:end)*r2d,'k-.x','MarkerSize',6,'LineWidth',1.6);
xlabel('Time (s)');
ylabel('Inclination (deg)');

figure(6)
hold on
grid on
box on
Delta = 5; Delta2 = 2;
set(figure(6),'Position',[500,200,560,360]);
plot(timeFSCP(1:Delta:end)*Tnond,QaFSCP(1:Delta:end),'b-o','MarkerSize',4.5,'LineWidth',1.6);
plot(timePSCP(1:Delta:end)*Tnond,QaPSCP(1:Delta:end),'r--d','MarkerSize',3,'LineWidth',1.6);
plot(timeGPOPS(1:Delta2:end)*Tnond,QaGPOPS(1:Delta2:end),'k-.x','MarkerSize',6,'LineWidth',1.6);
legend('Feasible-SCP','Picard-SCP','GPOPS');
xlabel('Time (s)');
ylabel('q\alpha (Rad\cdotN/m^2)');

