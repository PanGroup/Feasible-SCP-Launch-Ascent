%-------------------------------------------------------------------------%
% @brief        ����Jacobian Bk
% @author       Lance
% @date         2022.03.21
%-------------------------------------------------------------------------%
function [Bk1,Bk2,Btf,Bbendm]  =  calcuBk(tau,X1,X2,U1,U2,T0,Tm,Tf)
global globalParam projParam chebyParam
% ���򼸺β���
Lnond                          =  globalParam.Lnond;
Vnond                          =  globalParam.Vnond;
Rad0_A                         =  projParam.Rad0_A;
Iz_A                           =  projParam.Iz_A;
QaMax                          =  projParam.QaMax;
OmegaeMatrix                   =  projParam.OmegaeMatrix;

% Chebyshev-Picard����
TTdot                          =  chebyParam.TTdot;
Rdot                           =  chebyParam.Rdot;
Sdot                           =  chebyParam.Sdot;
T                              =  chebyParam.T;
V                              =  chebyParam.V;
TimesV                         =  TTdot*Rdot*Sdot*T*V;
TimesR                         =  TimesV*TimesV;

% ��������
NumX                           =  size(X1,2);
NumU                           =  size(U1,2);

% �ն�Լ��ƫ����
PosK_A                         =  X2(end,1:3)';
RadK_A                         =  PosK_A + Rad0_A;
RK_A                           =  norm(RadK_A);
VelK_A                         =  X2(end,4:6)';
VK_A                           =  norm(VelK_A);
RadxK_A                        =  RadK_A(1);
RadyK_A                        =  RadK_A(2);
RadzK_A                        =  RadK_A(3);
VelxK_A                        =  VelK_A(1);
VelyK_A                        =  VelK_A(2);
VelzK_A                        =  VelK_A(3);
Bk0                            =  [RadxK_A/RK_A, RadyK_A/RK_A, RadzK_A/RK_A, 0, 0, 0;
                                  0, 0, 0, VelxK_A/VK_A, VelyK_A/VK_A, VelzK_A/VK_A;
                                  VelxK_A, VelyK_A, VelzK_A, RadxK_A, RadyK_A, RadzK_A;
                                  Iz_A(2)*(-VelzK_A)+Iz_A(3)*VelyK_A, Iz_A(1)*VelzK_A+Iz_A(3)*(-VelxK_A), Iz_A(1)*(-VelyK_A)+Iz_A(2)*VelxK_A, ...
                                  Iz_A(2)*RadzK_A+Iz_A(3)*(-RadyK_A), Iz_A(1)*(-RadzK_A)+Iz_A(3)*RadxK_A, Iz_A(1)*RadyK_A+Iz_A(2)*(-RadxK_A)];
% ����Jacobian����
% �ն�Լ��-->��1�ο��Ʊ���
Fu1                            =  calcuFu1(tau,X1,U1,T0,Tm);
Bk1_Vel                        =  reshape(repmat((Tm-T0)/2*TimesV(end,:),NumU,1),1,[]).*reshape(Fu1,NumX/2,[]);
Bk1_Pos                        =  reshape(repmat((Tm-T0)/2*(Tm-T0)/2*TimesR(end,:),NumU,1),1,[]).*reshape(Fu1,NumX/2,[])...
                               +  reshape(repmat((Tf-Tm)*(Tm-T0)/2*TimesV(end,:),NumU,1),1,[]).*reshape(Fu1,NumX/2,[]);
Bk1                            =  Bk0*[Bk1_Pos;Bk1_Vel];
% �ն�Լ��-->��2�ο��Ʊ���
Fu2                            =  calcuFu2(tau,X2,U2,Tm,Tf);
Bk2_Vel                        =  reshape(repmat((Tf-Tm)/2*TimesV(end,:),NumU,1),1,[]).*reshape(Fu2,NumX/2,[]);
Bk2_Pos                        =  reshape(repmat((Tf-Tm)/2*(Tf-Tm)/2*TimesR(end,:),NumU,1),1,[]).*reshape(Fu2,NumX/2,[]);
Bk2                            =  Bk0*[Bk2_Pos;Bk2_Vel];
% �ն�Լ��-->��2���ն�ʱ��
RightTerms1                    =  sysModelLaunchACoord3DMatrix1(tau,X1,U1,T0,Tm);
RightTerms2                    =  sysModelLaunchACoord3DMatrix2(tau,X2,U2,Tm,Tf);
Btf_Vel                        =  TimesV(end,:)*RightTerms2/2;
Btf_Pos                        =  X1(1,4:6)+(Tm-T0)/2*TimesV(end,:)*RightTerms1+(Tf-Tm)/2*TimesR(end,:)*RightTerms2;
Btf                            =  Bk0*[Btf_Pos,Btf_Vel]';
% ���Լ��-->��1�ο��Ʊ���
Pos_A                          =  X1(:,1:3);
Vel_A                          =  X1(:,4:6);
Rad_A                          =  bsxfun(@plus,Pos_A,Rad0_A');
H_A                            =  sqrt(sum(Rad_A.*Rad_A,2)) - 1;
Rho                            =  calcuDensity(H_A*Lnond);
Vel_r                          =  Vel_A - Rad_A*OmegaeMatrix';
V_r                            =  sqrt(sum(Vel_r.*Vel_r,2));
q                              =  1/2.*Rho.*V_r.*V_r.*Vnond.*Vnond;
Bbendm                         =  Vel_r./V_r./cos(min(QaMax./q,pi/3));
