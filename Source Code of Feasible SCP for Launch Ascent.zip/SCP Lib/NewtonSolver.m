%%------------------------------------------------------------------------%
% @brief         projected-Newton solver
% @author        Lance
% @date          2019.11.22
%%------------------------------------------------------------------------%
function  outputGuid      =  NewtonSolver(tau,Xinit1,Xinit2,Uinit1,Uinit2,T0,Tm,Tfinit,Param)
global globalParam projParam chebyParam
% ȫ�ֱ���
Lnond                     =  globalParam.Lnond; 
Vnond                     =  globalParam.Vnond;
OmegaeMatrix              =  projParam.OmegaeMatrix;
Rad0_A                    =  projParam.Rad0_A;
Iz_A                      =  projParam.Iz_A;
QaMax                     =  projParam.QaMax;

% Chebyshev-Picard����
TTdot                     =  chebyParam.TTdot;
Rdot                      =  chebyParam.Rdot;
Sdot                      =  chebyParam.Sdot;
T                         =  chebyParam.T;
V                         =  chebyParam.V;
TimesV                    =  TTdot*Rdot*Sdot*T*V;
TimesR                    =  TimesV*TimesV;

% �ն�Լ�����������
Ytarg                     =  Param.Ytarg;
Error                     =  Param.Error;

% ��������
alpha                     =  Param.dampFactor;

% ״̬�����Ϳ��Ʊ���
X1                        =  Xinit1;
X2                        =  Xinit2;
U1                        =  Uinit1;
U2                        =  Uinit2;
Tf                        =  Tfinit;

% �ն�״̬(4Լ��)
PosK_A                    =  X2(end,1:3)';
VelK_A                    =  X2(end,4:6)';
RadK_A                    =  PosK_A + Rad0_A;
RK_A                      =  norm(RadK_A);
VK_A                      =  norm(VelK_A);
Y                         =  [RK_A,VK_A,dot(RadK_A,VelK_A),dot(Iz_A,cross(RadK_A,VelK_A))]'-Ytarg;

% ������Ϣ
iter                      =  0;
guidFlag                  =  0;
while true
    
    % Save the current states and controls
    Upre1                 =  U1;
    Upre2                 =  U2;
    Xpre1                 =  X1;
    Xpre2                 =  X2;
    Tfpre                 =  Tf;
    Ypre                  =  Y;
    
    % Update the control
    [dU1,dU2,dTf]         =  NewtonUpdate(tau,Xpre1,Xpre2,Upre1,Upre2,T0,Tm,Tfpre,Ypre);
    U1                    =  Upre1 + alpha*reshape(dU1,size(Upre1,2),[])';
    U2                    =  Upre2 + alpha*reshape(dU2,size(Upre2,2),[])';
    Tf                    =  Tfpre + alpha*dTf;

    % ���Լ������
    Pos_A                 =  Xpre1(:,1:3);
    Vel_A                 =  Xpre1(:,4:6);
    Rad_A                 =  bsxfun(@plus,Pos_A,Rad0_A');
    H_A                   =  sqrt(sum(Rad_A.*Rad_A,2))-1;
    Rho                   =  calcuDensity(H_A*Lnond);
    %
    Vel_r                 =  Vel_A - Rad_A*OmegaeMatrix';
    V_r                   =  sqrt(sum(Vel_r.*Vel_r,2));
    q                     =  1/2.*Rho.*V_r.*V_r.*Vnond.*Vnond;
    %
    Ib                    =  U1./sqrt(sum(U1.*U1,2));
    Phi_A                 =  atan(Ib(:,2)./Ib(:,1));
    Psi_A                 = -asin(Ib(:,3));
    Theta_A               =  atan(Vel_r(:,2)./Vel_r(:,1));
    Qa                    =  q.*(Phi_A - Theta_A);
    Phi_A(Qa<-QaMax)      =  Theta_A(Qa<-QaMax) - QaMax./q(Qa<-QaMax);
    Phi_A(Qa> QaMax)      =  Theta_A(Qa> QaMax) + QaMax./q(Qa> QaMax);
    U1                    =  [cos(Phi_A).*cos(Psi_A),sin(Phi_A).*cos(Psi_A),-sin(Psi_A)];

    % Update the state
    RightTerms1           =  sysModelLaunchACoord3DMatrix1(tau,Xpre1,U1,T0,Tm);
    RightTerms2           =  sysModelLaunchACoord3DMatrix2(tau,Xpre2,U2,Tm,Tf);
    X1(:,4:6)             =  X1(1,4:6) + (Tm-T0)/2*TimesV*RightTerms1;
    X1(:,1:3)             =  X1(1,1:3) + (Tm-T0)/2*X1(1,4:6).*(tau+1) + (Tm-T0)/2*(Tm-T0)/2*TimesR*RightTerms1;
    X2(:,4:6)             =  X1(end,4:6) + (Tf-Tm)/2*TimesV*RightTerms2;
    X2(:,1:3)             =  X1(end,1:3) + (Tf-Tm)/2*X1(end,4:6).*(tau+1) + (Tf-Tm)/2*(Tf-Tm)/2*TimesR*RightTerms2;
    for  k                =  1:1
        Xpre1             =  X1;
        Xpre2             =  X2;
        RightTerms1       =  sysModelLaunchACoord3DMatrix1(tau,Xpre1,U1,T0,Tm);
        RightTerms2       =  sysModelLaunchACoord3DMatrix2(tau,Xpre2,U2,Tm,Tf);
        X1(:,4:6)         =  X1(1,4:6) + (Tm-T0)/2*TimesV*RightTerms1;
        X1(:,1:3)         =  X1(1,1:3) + (Tm-T0)/2*X1(1,4:6).*(tau+1) + (Tm-T0)/2*(Tm-T0)/2*TimesR*RightTerms1;
        X2(:,4:6)         =  X1(end,4:6) + (Tf-Tm)/2*TimesV*RightTerms2;
        X2(:,1:3)         =  X1(end,1:3) + (Tf-Tm)/2*X1(end,4:6).*(tau+1) + (Tf-Tm)/2*(Tf-Tm)/2*TimesR*RightTerms2;
    end

    % Update the output
    PosK_A                =  X2(end,1:3)';
    VelK_A                =  X2(end,4:6)';   
    RadK_A                =  PosK_A + Rad0_A;
    RK_A                  =  norm(RadK_A);
    VK_A                  =  norm(VelK_A);
    Y                     =  [RK_A,VK_A,dot(RadK_A,VelK_A),dot(Iz_A,cross(RadK_A,VelK_A))]'-Ytarg;

    % Break Conditions
    iter                  =  iter + 1;
    if  iter              >  20
        guidFlag          =  0;
        break;
    end
    
    %if  sum(abs(Y)<=Error) == length(Error) && ... 
    %if  norm(U1-Upre1,inf) < 1E-3 && norm(U2-Upre2,inf) < 1E-3 && ...
    if  sum(abs(Y)<=Error) == length(Error) && ...
        norm(X1(end,:)-Xpre1(end,:)) < 1E-6 && norm(X2(end,:)-Xpre2(end,:)) < 1E-6
        guidFlag          =  1;
        break;
    end

end
outputGuid.guidFlag       =  guidFlag;
outputGuid.iter           =  iter;
outputGuid.X1             =  X1;
outputGuid.X2             =  X2;
outputGuid.U1             =  U1;
outputGuid.U2             =  U2;
outputGuid.Tf             =  Tf;
outputGuid.dY             =  Y;

