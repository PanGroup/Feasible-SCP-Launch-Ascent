%-------------------------------------------------------------------------%
% @brief                Newton updates
% @author               Lance
% @date                 2019.11.22
%-------------------------------------------------------------------------%
function [dU1,dU2,dTf]  =  NewtonUpdate(tau,Xpre1,Xpre2,Upre1,Upre2,T0,Tm,Tfpre,Ypre)
global chebyParam
NumU                    =  size(Upre1,2);

% Ȩ�ؾ���
R                       =  chebyParam.Weight;
InvR                    =  diag(reshape(repmat(1./R',NumU,1),1,[]));
Rt                      =  2;
InvRt                   =  1/Rt;

% Jacobian����
[Bk1,Bk2,Btf,~]         =  calcuBk(tau,Xpre1,Xpre2,Upre1,Upre2,T0,Tm,Tfpre);
Alamb                   =  Bk1*InvR*Bk1';
Blamb                   =  Bk2*InvR*Bk2';
Clamb                   =  Btf*InvRt*Btf';

% ���Ʊ�����������
dU1                     = -InvR*Bk1'*pinv(Alamb+Blamb+Clamb)*Ypre;
dU2                     = -InvR*Bk2'*pinv(Alamb+Blamb+Clamb)*Ypre;
dTf                     = -InvRt*Btf'*pinv(Alamb+Blamb+Clamb)*Ypre;

