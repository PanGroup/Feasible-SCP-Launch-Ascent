%-------------------------------------------------------------------------%
% @brief         Call Mosek solver
% @note:
% t->[tStart,tEnd] to tau->[-1,1]��
% t = (tEnd+tStart)/2 + (tEnd -tStart)/2*tau
% Xdot = f(t,X,U) <----> Xprime = (tEnd - tStart)/2*f(t,X,U)
% The discrete nodes are chosen as the CGL nodes, which remain unchanged
% The variable t at each node is computed from tau and t0/tf 
% The variable Tfinit/Tf/Tfpre represent the initial/current/previous Tf
% @author        Lance
% @date          2022.03.14
%-------------------------------------------------------------------------%
function  outputSimu             =  trajOptimizationFeasibleSCP()
global  globalParam modelParam projParam chebyParam
%% Global Parameters
% normalization parameters
d2r                              =  globalParam.d2r;
Lnond                            =  globalParam.Lnond;
Vnond                            =  globalParam.Vnond;
Tnond                            =  globalParam.Tnond;

% model parameters
tShutdown1                       =  modelParam.tShutdown1;
tShutdown2                       =  modelParam.tShutdown2;

% project parameters
Rf_A                             =  projParam.Rf_A;
Vf_A                             =  projParam.Vf_A;
localThetaf_A                    =  projParam.localThetaf_A;
inc                              =  projParam.inc;
Rad0_A                           =  projParam.Rad0_A;
Iz_A                             =  projParam.Iz_A;

% Chebyshev-Picard parameters
TTdot                            =  chebyParam.TTdot;
Rdot                             =  chebyParam.Rdot;
Sdot                             =  chebyParam.Sdot;
T                                =  chebyParam.T;
V                                =  chebyParam.V;
TimesV                           =  TTdot*Rdot*Sdot*T*V;
TimesR                           =  TimesV*TimesV;

%% Load The Initial Guess
initData                         =  load('.\Data Lib\nominalTraj.mat');
tinit0                           =  initData.tNominal;
Xinit0                           =  initData.xNominal(:,1:6);
Phi0                             =  initData.xNominal(:,7);
Psi0                             =  initData.xNominal(:,8);
Uinit0                           =  [cos(Phi0).*cos(Psi0),sin(Phi0).*cos(Psi0),-sin(Psi0)];

% for saving the intermediate solution
IntermSolutionIR1                =  zeros(10,6);
IntermSolutionIR2                =  zeros(10,6);

%% Trajectory Optimization Process
% the numbers of the terminal constraint/state/control
NumY                             =  4;
NumX                             =  6;
NumU                             =  3;

% terminal conditions
% K means the states at the burnoff time
% RK_A - Rf_A = 0
% VK_A - Vf_A = 0
% dot(RadK_A,VelK_A) - Rf_A*Vf_A*sin(localThetaf_A) = 0
% dot(Iz_A,cross(RadK_A,VelK_A)) - Rf_A*Vf_A*cos(localThetaf_A)*cos(inc) = 0

% terminal constraints
Ytarg                            =  [Rf_A,Vf_A,Rf_A*Vf_A*sin(localThetaf_A),Rf_A*Vf_A*cos(localThetaf_A)*cos(inc)]';
Error                            =  [10/Lnond,0.1/Vnond,0.01*d2r,0.01*d2r]';

% algorithm parameters for projected-Newton solver
algoParam.Ytarg                  =  Ytarg;
algoParam.Error                  =  Error;
algoParam.dampFactor             =  0.9;

% initial time/middle time/final time
% middle time means the final time of the 1st stage and the initial time of
% the 2nd stage
tStart                           =  60/Tnond;
tMid                             =  tShutdown1;                             
tEnd                             =  tShutdown2;

% the number of the discrete nodes
tau                              =  chebyParam.tau';
Num                              =  2*size(tau,1);

% initial guess of the state/control/final time
tinit1                           =  (tMid+tStart)/2 + (tMid-tStart)/2*tau;
Xinit1                           =  interp1(tinit0,Xinit0,tinit1,'linear','extrap');
Uinit1                           =  interp1(tinit0,Uinit0,tinit1,'linear','extrap');
tinit2                           =  (tEnd+tMid)/2 + (tEnd-tMid)/2*tau;
Xinit2                           =  interp1(tinit0,Xinit0,tinit2,'linear','extrap');
Uinit2                           =  interp1(tinit0,Uinit0,tinit2,'linear','extrap');

% state/control/final time
X1                               =  Xinit1;
U1                               =  Uinit1;
X2                               =  Xinit2;
U2                               =  Uinit2;
T0                               =  tStart;
Tm                               =  tMid;
Tf                               =  tEnd;

% the solving loop
iter                             =  0;
tic
while true
    
    % restoration process using projected-Newton method
    outputGuid                   =  NewtonSolver(tau,X1,X2,U1,U2,T0,Tm,Tf,algoParam);
    
    % the feasible intermediate iterate of state/control/final time/terminal constraints
    Xpre1                        =  outputGuid.X1;
    Xpre2                        =  outputGuid.X2;
    Upre1                        =  outputGuid.U1;
    Upre2                        =  outputGuid.U2;
    Tfpre                        =  outputGuid.Tf;
    Ypre                         =  outputGuid.dY;
    
    % combine the dynamics, initial/link conditions, and terminal constraints
    % for eliminating the state
    % linearize the conbined constraints and the bending moment constraint
    [Bk1,Bk2,Btf,Bbendm]         =  calcuBk(tau,Xpre1,Xpre2,Upre1,Upre2,T0,Tm,Tf);
    
    % call MOSEK for solving the resulting convex subproblem
    clear prob;
    
    % coefficients for objective function
    % note that no relaxation on terminal constraints is used
    prob.c                       =  [zeros(1,NumU*Num),1];
    
    % coefficients for control magnitude constraint (second-order parts)
    prob.qcsubk                  =  reshape(repmat(linspace(1,Num,Num),[NumU,1]),1,[]);
    prob.qcsubi                  =  linspace(1,NumU*Num,NumU*Num);
    prob.qcsubj                  =  linspace(1,NumU*Num,NumU*Num);
    prob.qcval                   =  2*ones(1,Num*NumU);
    
    % coefficients for linear constraints
    % coefficients for control magnitude constraint (linear parts)
    lc1                          =  zeros(Num,NumU*Num+1);
    % for linearized terminal constraints
    lc2                          =  [Bk1,Bk2,Btf;-Bk1,-Bk2,-Btf];
    % for linearized bending moment constraints
    lc3_subi                     =  reshape(repmat(linspace(1,Num/2,Num/2),[NumU,1]),1,[]);
    lc3_subj                     =  linspace(1,NumU*Num/2,NumU*Num/2);
    lc3_valij                    =  reshape(Bbendm',1,[]);
    lc3                          =  sparse(lc3_subi,lc3_subj,lc3_valij,Num/2,NumU*Num+1);
    prob.a                       =  [lc1;lc2;lc3];
    
    % upper bounds
    buc1                         =  ones(Num,1);
    buc2                         =  [-Ypre+Bk1*reshape(Upre1',[],1)+Bk2*reshape(Upre2',[],1)+Btf*Tfpre;...
                                      Ypre-Bk1*reshape(Upre1',[],1)-Bk2*reshape(Upre2',[],1)-Btf*Tfpre];
    buc3                         =  inf(Num/2,1);
    prob.buc                     =  [buc1;buc2;buc3];
    
    % lower bounds
    blc1                         = -inf(Num,1);
    blc2                         = -inf(2*NumY,1);
    blc3                         =  ones(Num/2,1);
    prob.blc                     =  [blc1;blc2;blc3];
    
    % bounds of solving variables-> use for the trust-region constraints
    % these constraints can be eliminated here, but we don't known if it works for other cases 
    prob.blx                     =  [-0.5*ones(NumU*Num,1)+reshape([Upre1;Upre2]',[],1);-5/Tnond+Tfpre];
    prob.bux                     =  [ 0.5*ones(NumU*Num,1)+reshape([Upre1;Upre2]',[],1); 5/Tnond+Tfpre];
    
    % call for mosekopt
    [~,res]                      =  mosekopt('minimize echo(0)',prob);
    
    % the optimal solution
    if strcmp(res.rcodestr, 'MSK_RES_OK')
        Z  =  res.sol.itr.xx;
    else
        disp('Failure!!!');  break; 
    end
    
    % update the controls/final time
    alpha                        =  1;
    U1                           =  (1-alpha)*Upre1  + alpha*reshape(Z(1:3*Num/2),3,[])';
    U2                           =  (1-alpha)*Upre2  + alpha*reshape(Z(3*Num/2+1:end-1),3,[])';
    Tf                           =  (1-alpha)*Tfpre  + alpha*Z(end);  

    % recover the states using second-order Picard iteration
    RightTerms1                  =  sysModelLaunchACoord3DMatrix1(tau,Xpre1,U1,T0,Tm);
    RightTerms2                  =  sysModelLaunchACoord3DMatrix2(tau,Xpre2,U2,Tm,Tf);
    X1(:,4:6)                    =  X1(1,4:6) + (Tm-T0)/2*TimesV*RightTerms1;
    X1(:,1:3)                    =  X1(1,1:3) + (Tm-T0)/2*X1(1,4:6).*(tau+1) + (Tm-T0)/2*(Tm-T0)/2*TimesR*RightTerms1;
    X2(:,4:6)                    =  X1(end,4:6) + (Tf-Tm)/2*TimesV*RightTerms2;
    X2(:,1:3)                    =  X1(end,1:3) + (Tf-Tm)/2*X1(end,4:6).*(tau+1) + (Tf-Tm)/2*(Tf-Tm)/2*TimesR*RightTerms2;
    for  k                       =  1:5
        Xpre1                    =  X1;
        Xpre2                    =  X2;
        RightTerms1              =  sysModelLaunchACoord3DMatrix1(tau,Xpre1,U1,T0,Tm);
        RightTerms2              =  sysModelLaunchACoord3DMatrix2(tau,Xpre2,U2,Tm,Tf);
        X1(:,4:6)                =  X1(1,4:6) + (Tm-T0)/2*TimesV*RightTerms1;
        X1(:,1:3)                =  X1(1,1:3) + (Tm-T0)/2*X1(1,4:6).*(tau+1) + (Tm-T0)/2*(Tm-T0)/2*TimesR*RightTerms1;
        X2(:,4:6)                =  X1(end,4:6) + (Tf-Tm)/2*TimesV*RightTerms2;
        X2(:,1:3)                =  X1(end,1:3) + (Tf-Tm)/2*X1(end,4:6).*(tau+1) + (Tf-Tm)/2*(Tf-Tm)/2*TimesR*RightTerms2;
    end
    
    % update the terminal constraints
    PosK_A                       =  X2(end,1:3)';
    VelK_A                       =  X2(end,4:6)';   
    RadK_A                       =  PosK_A + Rad0_A;
    RK_A                         =  norm(RadK_A);
    VK_A                         =  norm(VelK_A);
    Y                            =  [RK_A,VK_A,dot(RadK_A,VelK_A),dot(Iz_A,cross(RadK_A,VelK_A))]'-Ytarg;

    % maximum iteration number
    iter                         =  iter + 1;
    IntermSolutionIR1(iter,:)    =  [iter,Tfpre,Ypre'];
    IntermSolutionIR2(iter,:)    =  [iter,Tf,Y'];
    if  iter                     >  30 
        disp('Failure!!'); break; 
    end
    
    % convergence conditions
    if  norm(U1-Upre1,inf) < 5E-3 && norm(U2-Upre2,inf) < 5E-3 && ...
        norm(X1(:,1:3)-Xpre1(:,1:3),inf) < 1/Lnond && norm(X2(:,1:3)-Xpre2(:,1:3),inf) < 1/Lnond &&...
        norm(X1(:,4:6)-Xpre1(:,4:6),inf) < 1/Vnond && norm(X2(:,4:6)-Xpre2(:,4:6),inf) < 1/Vnond && abs(Tf-Tfpre) < 0.1/Tnond
        disp('Success!'); disp(['Iteration number��', num2str(iter)]); break;
    end
end
toc

time1    =  (Tm+T0)/2 + (Tm-T0)/2*tau;
time2    =  (Tf+Tm)/2 + (Tf-Tm)/2*tau;
time     =  [time1;time2(2:end)];
state    =  [X1;X2(2:end,:)];
control  =  [U1;U2(2:end,:)];

outputSimu.time     =  time;
outputSimu.state    =  state;
outputSimu.control  =  control;

save('.\Data Lib\IntermSolution-FSCP.mat','IntermSolutionIR1','IntermSolutionIR2');
