%-------------------------------------------------------------------------%

%-------------------------------------------------------------------------%
function  modelParam                 =  modelParamSetting()
global globalParam

Lnond                                =  globalParam.Lnond;
Vnond                                =  globalParam.Vnond;
Tnond                                =  globalParam.Tnond;
Fnond                                =  globalParam.Fnond;
Mnond                                =  globalParam.Mnond;
 
modelParam.MaxStage                  =  3;
modelParam.MainEngine                =  0;

tInit                                =  30;

TotalMass                            =  (2000E3 - 1600*5*tInit)/Mnond;
TotalMassb                           =  (320E3 - 1600*tInit)/Mnond;
TotalMass1                           =  (320E3 - 1600*tInit)/Mnond;
TotalMass2                           =  400E3/Mnond;
FairingMass                          =  0/Mnond;

modelParam.TotalMass                 =  TotalMass;
modelParam.TotalMassb                =  TotalMassb;
modelParam.TotalMass1                =  TotalMass1;
modelParam.TotalMass2                =  TotalMass2;
modelParam.FairingMass               =  FairingMass;

DryMassb                             =  25E3/Mnond;
DryMass1                             =  25E3/Mnond;
DryMass2                             =  100E3/Mnond;

FuelMassb                            =  (TotalMassb - DryMassb)/Mnond;
FuelMass1                            =  (TotalMass1 - DryMass1)/Mnond;
FuelMass2                            =  (TotalMass2 - DryMass2)/Mnond;
modelParam.FuelMassStageb            =  FuelMassb;
modelParam.FuelMassStage1            =  FuelMass1;
modelParam.FuelMassStage2            =  FuelMass2;

GroundIspb                           =  3500/Vnond;
GroundIsp1                           =  3500/Vnond;
VacuumIsp2                           =  3500/Vnond;
modelParam.GroundIspb                =  GroundIspb;
modelParam.GroundIsp1                =  GroundIsp1;
modelParam.VacuumIsp2                =  VacuumIsp2;

modelParam.Srefb                     =  2;
modelParam.Sref1                     =  2;                                 % m^2��������--�ܶȺͲο���������й�һ��
modelParam.Sref2                     =  0;

massrateb                            =  1600/(Mnond/Tnond);
massrate1                            =  1600/(Mnond/Tnond);                % kg/s ����ͨ��о����׼�����
massrate2                            =  850/(Mnond/Tnond);                 % kg/s ������׼�����
modelParam.massrateb                 =  massrateb;
modelParam.massrate1                 =  massrate1;
modelParam.massrate2                 =  massrate2;

modelParam.ExitAreab                 =  5;                                 % m^2,������������--δ��һ��
modelParam.ExitArea1                 =  5;

thruttleRatiob1                      =  1;
thruttleRatiob2                      =  1;
thruttleRatio1                       =  1;
thruttleRatio2                       =  1;
modelParam.thruttleRatiob1           =  thruttleRatiob1;
modelParam.thruttleRatiob2           =  thruttleRatiob2;
modelParam.thruttleRatio1            =  thruttleRatio1;
modelParam.thruttleRatio2            =  thruttleRatio2;


tRef0                                =  tInit / Tnond;
tShutdownb1                          =  tRef0 + FuelMassb/(massrateb*thruttleRatiob1);
tShutdownb2                          =  tRef0 + FuelMassb/(massrateb*thruttleRatiob2);
tShutdown1                           =  tRef0 + FuelMass1/(massrate1*thruttleRatio1);
tFairing                             =  tShutdown1 + 7 / Tnond;
tShutdown2                           =  tShutdown1 + FuelMass2/(massrate2*thruttleRatio2);

modelParam.tRef0                     =  tRef0;
modelParam.tShutdownb1               =  tShutdownb1;
modelParam.tShutdownb2               =  tShutdownb2;
modelParam.tShutdown1                =  tShutdown1;
modelParam.tFairing                  =  tFairing;
modelParam.tShutdown2                =  tShutdown2;


