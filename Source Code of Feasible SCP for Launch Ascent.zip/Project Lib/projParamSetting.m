%-------------------------------------------------------------------------%
% @brief                      �趨�������
% @param[out]
%-------------------------------------------------------------------------%
function projParam              =  projParamSetting()

global globalParam
d2r                             =  globalParam.d2r;
r2d                             =  globalParam.r2d;
Re                              =  globalParam.nondim_Re;
Ae                              =  globalParam.nondim_Ae;
Be                              =  globalParam.nondim_Be;
Omegae                          =  globalParam.nondim_Omegae;

Lnond                           =  globalParam.Lnond;
Vnond                           =  globalParam.Vnond;
Tnond                           =  globalParam.Tnond;

% ����������γ�ȣ���������=Բ��
L0                              =  110.95*d2r;
B0                              =  19.61*d2r;
A0                              =  90.01*d2r;
projParam.L0                    =  L0;
projParam.B0                    =  B0;
projParam.A0                    =  A0;

% �����߳�
H0                              =  10/Lnond;
projParam.H0                    =  H0;

% ��������γ��
Phi0                            =  atan(Ae^2/Be^2*tan(B0));

% �������ľ�
%R0                              =  Ae*Be/sqrt(Ae^2*sin(Phi0)^2 + Be^2*cos(Phi0)^2);
R0                              =  Re;

% �����ʸ���ڷ����������ϵ�·���
R0x_A                           = -R0*sin(B0 - Phi0)*cos(A0);
R0y_A                           =  R0*cos(B0 - Phi0) + H0;
R0z_A                           =  R0*sin(B0 - Phi0)*sin(A0);
Rad0_A                          =  [R0x_A,R0y_A,R0z_A]';
projParam.Rad0_A                =  Rad0_A;

% ���Ĺ���ϵָ�򱱼��ĵ�λʸ���ڷ������ϵ�еķ���
Iz_A                            =  [cos(B0)*cos(A0),sin(B0),-cos(B0)*sin(A0)]';
projParam.Iz_A                  =  Iz_A;

% ������ת���ٶ��ڷ����������ϵ�µķ���
OmegaeX                         =  Omegae*cos(B0)*cos(A0);
OmegaeY                         =  Omegae*sin(B0);
OmegaeZ                         = -Omegae*cos(B0)*sin(A0);
OmegaeVect                      =  [OmegaeX,OmegaeY,OmegaeZ]';
OmegaeMatrix                    =  [0,-OmegaeZ,OmegaeY;OmegaeZ,0,-OmegaeX;-OmegaeY,OmegaeX,0];
projParam.OmegaeVect            =  OmegaeVect;
projParam.OmegaeMatrix          =  OmegaeMatrix;


% �ٶ�����ϵ�³�ʼλ��
x0                              =  0/Lnond;
y0                              =  0/Lnond;
V0                              =  0/Vnond;
theta0                          =  pi/2;
projParam.State0_VelCoord_2D    =  [x0,y0,V0,theta0]';
projParam.Statef_VelCoord_2D    =  [0,0,0,0]';

% ��������ϵ�³�ʼλ��
x0                              =  0/Lnond;
y0                              =  0/Lnond;
z0                              =  0/Lnond;
Vx0                             =  0/Vnond;
Vy0                             =  0/Vnond;
Vz0                             =  0/Vnond;
projParam.State0_LaunchCoord_3D =  [x0,y0,z0,Vx0,Vy0,Vz0]';

% �����������ϵ�³�ʼ״̬
Pos0_A                         =  [0,0,0]';
Vel0_A                         =  OmegaeMatrix * Rad0_A;
projParam.State0_LaunchACoord_3D  =  [Pos0_A;Vel0_A];

% �������(4Լ�����볤�ᣬƫ���ʣ������ǣ�������)
a                              =  Re + 400E3/Lnond;
e                              =  0;
inc                            =  20*d2r;
f                              =  0;
Rf_A                           =  a*(1 - e^2)/(1 + e*cos(f));
Vf_A                           =  sqrt(2/Rf_A - 1/a);
localThetaf_A                  =  atan(e*sin(f)/(1 + e*cos(f)));
projParam.Rf_A                 =  Rf_A;
projParam.Vf_A                 =  Vf_A;
projParam.localThetaf_A        =  localThetaf_A;
projParam.inc                  =  inc;

% ���Լ��
QaMax                          =  2000;
projParam.QaMax                =  QaMax;

