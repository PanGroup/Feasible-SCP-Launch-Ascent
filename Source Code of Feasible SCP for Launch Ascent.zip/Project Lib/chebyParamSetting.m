%%
function chebyParam  =  chebyParamSetting(NumCheby)

%%
% Chebyshev-Picard Setting
chebyParam.NumCheby  = NumCheby;
%----
% Clenshaw-Curtis quadrature scheme
% RR = zeros(NumCheby + 1,1);
% if mod(NumCheby,2) == 0
%     RR(1) = 1/(NumCheby^2 - 1);
%     RR(end) = RR(1);
%     for i = 1:NumCheby/2
%         sumtemp = 0;
%         for j = 0:NumCheby/2
%             if j == 0 || j == NumCheby/2
%                 term = 1/2*(1/(1-4*j^2)*cos(2*pi*j*i/NumCheby));
%             else
%                 term = 1/(1-4*j^2)*cos(2*pi*j*i/NumCheby);
%             end
%             sumtemp = sumtemp + term;
%         end
%         RR(i+1) = 4/NumCheby*sumtemp;
%         RR(NumCheby-i+1) = 4/NumCheby*sumtemp;
%     end
% else
%     RR(1) = 1/(NumCheby^2);
%     RR(end) = RR(1);
%     for i = 1:(NumCheby-1)/2
%         sumtemp = 0;
%         for j = 0:(NumCheby-1)/2
%             if j == 0 || j == (NumCheby-1)/2
%                 term = 1/2*(1/(1-4*j^2)*cos(2*pi*j*i/NumCheby));
%             else
%                 term = 1/(1-4*j^2)*cos(2*pi*j*i/NumCheby);
%             end
%             sumtemp = sumtemp + term;
%         end
%         RR(i+1) = 4/NumCheby*sumtemp;
%         RR(NumCheby-i+1) = 4/NumCheby*sumtemp;
%     end
% end
%Param.Weight = RR;

% Clenshaw-Curtis quadrature scheme
if mod(NumCheby,2) == 0
    RR = zeros(NumCheby + 1,1);
    RR(1) = 1/(NumCheby^2 - 1);
    RR(end) = RR(1);
    for i = 1:NumCheby/2
        sumtemp = 0;
        for j = 0:NumCheby/2
            if j == 0 || j == NumCheby/2
                term = 1/2*(1/(1-4*j^2)*cos(2*pi*j*i/NumCheby));
            else
                term = 1/(1-4*j^2)*cos(2*pi*j*i/NumCheby);
            end
            sumtemp = sumtemp + term;
        end
        RR(i+1) = 4/NumCheby*sumtemp;
        RR(NumCheby-i+1) = 4/NumCheby*sumtemp;
    end
    chebyParam.Weight = RR;
else
    N = NumCheby;
    theta = pi*(0:N)'/N;
    w = zeros(N+1,1); ii = 2:N; v = ones(N-1,1);
    w(1) = 1/N^2;
    w(N+1) = w(1);
    for k = 1:(N-1)/2
        v = v - 2*cos(2*k*theta(ii))/(4*k^2-1);
    end
    w(ii) = 2*v/N;
    chebyParam.Weight = w;
end
%
%----

% Discrete times
chebyParam.tau       = fliplr(cos((0:NumCheby).*pi./NumCheby));
% Matrix R
chebyParam.R         = diag([1,1./2./(1:NumCheby)]);
% Matrix S
S               = (tril(ones(NumCheby+1),-1) - tril(ones(NumCheby+1),-2)) ...
                - (triu(ones(NumCheby+1), 1) - triu(ones(NumCheby+1), 2));
S(1,1)          = 1;
S(1,2)          = -1/2;
S(1,end)        = (-1)^(NumCheby+1)*1/(NumCheby-1);
K               = (2 : NumCheby-1);
S(1,3:end-1)    = (-1).^(K+1).*(1./(K-1) - 1./(K+1));
chebyParam.S         = S;
% Matrix T
chebyParam.T         = ChebyshevPolynomial((0:NumCheby)',chebyParam.tau);
% Matrix V
chebyParam.V         = diag([1,2*ones(1,NumCheby-1),1]./NumCheby);
%
% Matrix TT
chebyParam.TT        = ChebyshevPolynomial((0:NumCheby),chebyParam.tau');
% Matric VV
chebyParam.VV        = diag([1/2,ones(1,NumCheby)]);
%%
chebyParam.Sdot      = eye(NumCheby+1) - (triu(ones(NumCheby+1),2) - triu(ones(NumCheby+1),3));
chebyParam.Rdot      = diag(1./2./(1:NumCheby+1));
chebyParam.TTdot     = ChebyshevPolynomial((1:NumCheby+1),chebyParam.tau') ...
                     - ChebyshevPolynomial((1:NumCheby+1),-ones(NumCheby+1,1));
%%
%chebyParam.Chi0         =  zeros(NumCheby+1,6);
%chebyParam.Chi0(1,:)    =  2*[chebyParam.x0,chebyParam.y0,chebyParam.z0,chebyParam.V0,chebyParam.gamma0,chebyParam.psi0];

end

function Tk = ChebyshevPolynomial(k,tau)
%The Chebyshev polynomial,T, corresponding to degree k
Tk = cos(bsxfun(@times,k,acos(tau)));
end

