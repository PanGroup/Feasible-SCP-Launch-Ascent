%-------------------------------------------------------------------------%
% ���ݴ���
%-------------------------------------------------------------------------%
clc
clear
close all

% ���ù���·��
currentPath = pwd;
addpath(genpath(currentPath));

% ȫ�ֲ���
global globalParam modelParam projParam
globalParam    =  globalParamSetting();
projParam      =  projParamSetting();
modelParam     =  modelParamSetting();
Lnond          =  globalParam.Lnond;
Vnond          =  globalParam.Vnond;
Tnond          =  globalParam.Tnond;
d2r            =  globalParam.d2r;
r2d            =  globalParam.r2d;
tShutdown2     =  modelParam.tShutdown2;
OmegaeMatrix   =  projParam.OmegaeMatrix;
Rad0_A         =  projParam.Rad0_A;
Iz_A           =  projParam.Iz_A;
Rf_A           =  projParam.Rf_A;
Vf_A           =  projParam.Vf_A;
Incf           =  projParam.inc;
LocalThetaf_A  =  projParam.localThetaf_A;

% �����м���
IntermSolutionFSCP  =  load('.\Data Lib\IntermSolution-FSCP.mat');
IntermSolutionPSCP  =  load('.\Data Lib\IntermSolution-PSCP.mat');

IntermSolutionFSCPIR1 = IntermSolutionFSCP.IntermSolutionIR1;
IntermSolutionFSCPIR2 = IntermSolutionFSCP.IntermSolutionIR2;
IntermSolutionPSCP    = IntermSolutionPSCP.IntermSolution;

Rf0      = -0.0312937775174045;
Vf0      =  0.0456569063585844;
Thetaf0  =  0.0003393003721404;
Incf0    =  0.0157006401484041;
LengthFSCP  = sum(IntermSolutionFSCPIR1(:,1)>=1);
LengthPSCP  = sum(IntermSolutionPSCP(:,1)>=1);

% Ŀ�꺯��
figure(1)
hold on
grid on
box on
set(figure(1),'Position',[500,200,560,360]);
plot((0:LengthFSCP)',[tShutdown2;IntermSolutionFSCPIR2(1:LengthFSCP,2)]*Tnond,'b-o','MarkerSize',5,'LineWidth',1.8);
plot((0:LengthFSCP)',[tShutdown2;IntermSolutionFSCPIR1(1:LengthFSCP,2)]*Tnond,'b-.*','MarkerSize',5.5,'LineWidth',1.8);
plot((0:LengthPSCP)',[tShutdown2;IntermSolutionPSCP(1:LengthPSCP,2)]*Tnond,'r--d','MarkerSize',5,'LineWidth',1.8);
legend('Feasible-SCP-Optimization phase','Feasible-SCP-Feasible phase','Picard-SCP');
xlabel('Iteration number');
ylabel('Value of the objective (s)')

figure(2)
set(figure(2),'Position',[500,200,560,360]);
semilogy((0:LengthFSCP)',abs([Rf0;IntermSolutionFSCPIR2(1:LengthFSCP,3)])*Lnond,'b-o','MarkerSize',5,'LineWidth',1.8);
hold on
semilogy((0:LengthFSCP)',abs([Rf0;IntermSolutionFSCPIR1(1:LengthFSCP,3)])*Lnond,'b-.*','MarkerSize',5.5,'LineWidth',1.8);
semilogy((0:LengthPSCP)',abs([Rf0;IntermSolutionPSCP(1:LengthPSCP,3)])*Lnond,'r--d','MarkerSize',5,'LineWidth',1.8);
grid on
box on
legend('Feasible-SCP-Optimization Phase','Feasible-SCP-Feasible Phase','Picard-SCP');
xlabel('Iteration number');
ylabel('|r_f - r^*_f| (m)')

figure(3)
set(figure(3),'Position',[500,200,560,360]);
semilogy((0:LengthFSCP)',abs([Rf0;IntermSolutionFSCPIR2(1:LengthFSCP,4)])*Vnond,'b-o','MarkerSize',5,'LineWidth',1.8);
hold on
semilogy((0:LengthFSCP)',abs([Rf0;IntermSolutionFSCPIR1(1:LengthFSCP,4)])*Vnond,'b-.*','MarkerSize',5.5,'LineWidth',1.8);
semilogy((0:LengthPSCP)',abs([Rf0;IntermSolutionPSCP(1:LengthPSCP,4)])*Vnond,'r--d','MarkerSize',5,'LineWidth',1.8);
grid on
box on
xlabel('Iteration number');
ylabel('|v_f - v_f^*| (m/s)')

figure(4)
set(figure(4),'Position',[500,200,560,360]);
semilogy((0:LengthFSCP)',abs([Rf0;IntermSolutionFSCPIR2(1:LengthFSCP,5)])*r2d,'b-o','MarkerSize',5,'LineWidth',1.8);
hold on
semilogy((0:LengthFSCP)',abs([Rf0;IntermSolutionFSCPIR1(1:LengthFSCP,5)])*r2d,'b-.*','MarkerSize',5.5,'LineWidth',1.8);
semilogy((0:LengthPSCP)',abs([Rf0;IntermSolutionPSCP(1:LengthPSCP,5)])*r2d,'r--d','MarkerSize',5,'LineWidth',1.8);
grid on
box on
xlabel('Iteration number');
ylabel('|\gamma_f - \gamma_f^*| (deg)')

figure(5)
set(figure(5),'Position',[500,200,560,360]);
semilogy((0:LengthFSCP)',abs([Rf0;IntermSolutionFSCPIR2(1:LengthFSCP,6)])*r2d,'b-o','MarkerSize',5,'LineWidth',1.8);
hold on
semilogy((0:LengthFSCP)',abs([Rf0;IntermSolutionFSCPIR1(1:LengthFSCP,6)])*r2d,'b-.*','MarkerSize',5.5,'LineWidth',1.8);
semilogy((0:LengthPSCP)',abs([Rf0;IntermSolutionPSCP(1:LengthPSCP,6)])*r2d,'r--d','MarkerSize',5,'LineWidth',1.8);
grid on
box on
xlabel('Iteration number');
ylabel('|i_f - i^*_f| (deg)')

