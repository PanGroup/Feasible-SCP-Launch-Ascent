%
function  [CX1,CY1,CZ1]     =  calcuAeroDynamics(aeroFlag,alpha,beta,Alt,Vel)
alt                         =  Alt/1E3;
mach                        =  Vel/340;

CX1                         =  calcuCX1(aeroFlag,mach,alt);

CNa                         =  calcuCNa(aeroFlag,mach);
CY1                         =  CNa.*alpha*180/pi;
CZ1                         = -CNa.*beta*180/pi;

end

function  CNa               =  calcuCNa(aeroFlag,mach)

x                           =  mach;
x(x < 0.4)                  =  0.4;
x(x > 7.0)                  =  7.0;

if  aeroFlag                == 1
    
     p1                     =  0.000396;
     p2                     = -0.005095;
     p3                     =  0.0137;
     p4                     =  0.03566;
     p5                     =  0.2749;
     CNa                    =  p1.*x.^4 + p2.*x.^3 + p3.*x.^2 + p4.*x + p5;

else
end

end

function  CX1               =  calcuCX1(aeroFlag,mach,alt)

x                           =  mach;
y                           =  alt;

x(x < 0.4)                  =  0.4;
x(x > 7.0)                  =  7.0;

y(y < 0)                    =  0;
y(y > 80)                   =  80;

if  aeroFlag                == 1
    p00                     = -2.336;
    p10                     =  12.72;
    p01                     = -0.01088;
    p20                     = -7.971;
    p11                     =  0.02492;
    p02                     =  4.527e-05;
    p30                     =  2.11;
    p21                     = -0.01493;
    p12                     =  0.0002394;
    p40                     = -0.2563;
    p31                     =  0.003182;
    p22                     = -7.436e-05;
    p50                     =  0.01174;
    p41                     = -0.0002188;
    p32                     =  6.083e-06;
    CX1                     =  p00 + p10.*x + p01.*y + p20.*x.^2 + p11.*x.*y + p02.*y.^2 + p30.*x.^3 + p21.*x.^2.*y...
                            +  p12.*x.*y.^2 + p40.*x.^4 + p31.*x.^3.*y + p22.*x.^2.*y.^2 + p50.*x.^5 + p41.*x.^4.*y + p32.*x.^3.*y.^2;

else
end

end


