1. main_for_FeasibleSCP
(1) use MATLAB-2018 (or above)
(2) use MOSEK

2. main_for_PicardSCP
(1) use MATLAB-2018 (or above)
(2) use MOSEK

3. PlotFigure.m for intermediate solutions

4. PlotFigure2.m for final errors and also the comparisons
