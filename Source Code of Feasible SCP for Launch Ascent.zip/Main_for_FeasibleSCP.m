%-------------------------------------------------------------------------%
% @brief   main function of Picard-based SCP
% @note    use MATLAB-v2018b (or above) and MOSEK
% @author  Lance (Yangyang Ma)(mayy@mail.nwpu.edu.cn)
% @data    04/07/2022
%-------------------------------------------------------------------------%
clc
clear
close all

currentPath = pwd;
addpath(genpath(currentPath));

global  globalParam
global  modelParam
global  projParam
global  chebyParam

Num                                =  100;
globalParam                        =  globalParamSetting();
modelParam                         =  modelParamSetting();
projParam                          =  projParamSetting();
chebyParam                         =  chebyParamSetting(Num);

outputSolver                       =  trajOptimizationFeasibleSCP();
tNominal                           =  outputSolver.time;
xNominal                           =  outputSolver.state;
uNominal                           =  outputSolver.control;

save('.\Data Lib\resultTraj-FeasibleSCP.mat','tNominal','xNominal','uNominal')

rmpath(genpath(currentPath));


